Resource: dynamic_Lighting_projectiles v1.0.3
contact: knoblauch700@o2.pl

This resource lets You create some light effects related to player activity - shooting,
throwing molotovs, vehicle explosions and so on. It uses custom functions
introduced in dynamic_lighting resource. It works for most of the weapons, except minigun
and flamethrower. I may do something about it, but later.

Have fun.

