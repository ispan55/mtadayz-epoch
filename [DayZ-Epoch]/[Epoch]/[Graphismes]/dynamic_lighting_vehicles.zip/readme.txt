Resource: dynamic_Lighting_vehicles v1.0.2
video: https://www.youtube.com/watch?v=2t_bje_XjUY
contact: knoblauch700@o2.pl

This resource lets You create per pixel lights for vehicles. It uses custom functions
introduced in dynamic_lighting resource. It works for most of the vehicles, including trains.
You can easily change light properties using variables in c_vehicleLight.lua
Not much left to say.

Have fun.

